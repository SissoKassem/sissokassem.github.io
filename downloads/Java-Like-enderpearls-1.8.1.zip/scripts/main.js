import { world, system } from "@minecraft/server";

const DEBUG = false;
const pearlStateById = new Map();
const ownerOrphanedPearls = new Map(); // keyed by player NAME (persists across relogs)
const activePlayers = new Map(); // id -> name (session id -> persistent name)
const portalCooldowns = new Map();
let tickCount = 0;

// Blocks a pearl can freely pass through — never counted as an "impact".
const NON_SOLID_BLOCKS = new Set([
  "minecraft:air",
  "minecraft:water",
  "minecraft:flowing_water",
  "minecraft:lava",
  "minecraft:flowing_lava",
  "minecraft:bubble_column"
]);

// Vanilla ender pearl teleport has a chance to spawn an endermite at the
// arrival point (only when the world isn't on peaceful difficulty and
// mob spawning is enabled).
const ENDERMITE_SPAWN_CHANCE = 0.05;

function log(...args) {
  if (DEBUG) console.warn("[pearl-persist]", ...args);
}

function getAllDimensions() {
  try {
    if (typeof world.getDimensions === "function") return world.getDimensions();
    const ids = ["minecraft:overworld", "minecraft:the_nether", "minecraft:the_end", "minecraft:nether", "minecraft:end"];
    const dims = [];
    for (const id of ids) {
      try {
        const d = world.getDimension(id);
        if (d) dims.push(d);
      } catch (e) {
        // ignore
      }
    }
    return dims;
  } catch (e) {
    return [];
  }
}

function normalizeDimensionId(dimensionId) {
  if (!dimensionId) return "";
  return dimensionId.toString().replace(/^minecraft:/, "").toLowerCase();
}

function getDimensionById(dimensionId) {
  if (!dimensionId) return null;
  try {
    if (typeof world.getDimension === "function") {
      try {
        const direct = world.getDimension(dimensionId);
        if (direct) return direct;
      } catch (e) {
        // ignore
      }
    }
  } catch (e) {
    // ignore
  }

  const normalized = normalizeDimensionId(dimensionId);
  for (const dimension of getAllDimensions()) {
    if (!dimension || !dimension.id) continue;
    const id = dimension.id.toString().toLowerCase();
    const simple = id.replace(/^minecraft:/, "");
    if (id === normalized || simple === normalized || id.endsWith(`:${normalized}`) || simple === normalized) {
      return dimension;
    }
    if (id.includes(normalized) || simple.includes(normalized)) {
      return dimension;
    }
  }

  return null;
}

function vectorToObject(vector) {
  return { x: vector.x, y: vector.y, z: vector.z };
}

function objectToVector(obj) {
  return { x: obj.x, y: obj.y, z: obj.z };
}

function getBlockTypeAt(dimension, location) {
  if (!dimension || !location) return null;
  try {
    const block = dimension.getBlock({
      x: Math.floor(location.x),
      y: Math.max(0, Math.floor(location.y)),
      z: Math.floor(location.z)
    });
    return block ? block.typeId : null;
  } catch (e) {
    return null;
  }
}

// Impact detection is purely block-based: a pearl is only "impacted" if
// it is currently overlapping a solid block. Velocity is never checked.
// NON_SOLID_BLOCKS lists every block type a pearl should pass through
// untouched; add to it if another passable block type causes false
// impacts (e.g. signs, ladders, vines, kelp).
function isPearlImpactCandidate(pearl) {
  if (!pearl || !pearl.isValid) return false;

  const block = getBlockTypeAt(pearl.dimension, pearl.location);
  if (!block) return false;

  return !NON_SOLID_BLOCKS.has(block);
}

function teleportPlayer(owner, destination) {
  if (!owner || !owner.isValid || !destination) return;

  const dimension = getDimensionById(destination.dimensionId) || owner.dimension || null;
  if (!dimension) {
    console.warn(`[pearl-persist][DIAG] teleportPlayer: no dimension resolved for ${owner.name}, aborting`);
    return;
  }

  try {
    // Correct API shape: second arg is a TeleportOptions object, not a
    // bare Dimension. Passing the dimension directly here (as earlier
    // versions did) doesn't match the API and can silently misbehave.
    owner.teleport(destination.location, { dimension });
    console.warn(`[pearl-persist][DIAG] teleportPlayer: teleport() succeeded for ${owner.name} to ${destination.location.x.toFixed(1)}, ${destination.location.y.toFixed(1)}, ${destination.location.z.toFixed(1)} in ${dimension.id}`);
  } catch (e) {
    console.warn(`[pearl-persist][DIAG] teleportPlayer: teleport() threw for ${owner.name}:`, e);
    try {
      if (typeof owner.runCommandAsync === "function") {
        const x = destination.location.x.toFixed(2);
        const y = destination.location.y.toFixed(2);
        const z = destination.location.z.toFixed(2);
        owner.runCommandAsync(`tp @s ${x} ${y} ${z}`);
        console.warn(`[pearl-persist][DIAG] teleportPlayer: fell back to runCommandAsync for ${owner.name} (same-dimension only)`);
      } else {
        console.warn(`[pearl-persist][DIAG] teleportPlayer: no runCommandAsync available, teleport failed entirely for ${owner.name}`);
      }
    } catch (err) {
      console.warn(`[pearl-persist][DIAG] teleportPlayer: runCommandAsync fallback also threw for ${owner.name}:`, err);
    }
  }
}

function isPeacefulDifficulty(dimension) {
  try {
    const difficulty = world.getDifficulty ? world.getDifficulty() : null;
    if (difficulty === null || difficulty === undefined) return false;
    const value = typeof difficulty === "object" && "toString" in difficulty
      ? difficulty.toString().toLowerCase()
      : String(difficulty).toLowerCase();
    return value === "peaceful" || value === "0";
  } catch (e) {
    return false;
  }
}

function isMobSpawningEnabled() {
  try {
    if (world.gameRules && typeof world.gameRules.doMobSpawning === "boolean") {
      return world.gameRules.doMobSpawning;
    }
    if (typeof world.getGameRules === "function") {
      const rules = world.getGameRules();
      if (rules && typeof rules.doMobSpawning === "boolean") return rules.doMobSpawning;
    }
  } catch (e) {
    // ignore
  }
  return true;
}

function maybeSpawnEndermite(dimension, location) {
  if (!dimension || !location) return;
  if (isPeacefulDifficulty(dimension)) return;
  if (!isMobSpawningEnabled()) return;
  if (Math.random() >= ENDERMITE_SPAWN_CHANCE) return;

  try {
    dimension.spawnEntity("minecraft:endermite", location);
    log(`Spawned endermite at ${location.x.toFixed(1)}, ${location.y.toFixed(1)}, ${location.z.toFixed(1)}`);
  } catch (e) {
    // ignore — e.g. spawn blocked or entity not available
  }
}

function handlePearlImpact(pearl) {
  if (!pearl || !pearl.isValid) return;
  if (portalCooldowns.has(pearl.id)) return;

  const owner = getPearlOwner(pearl);
  if (!owner || !owner.isValid) return;

  const targetLocation = {
    x: pearl.location.x,
    y: Math.max(1, pearl.location.y + 0.5),
    z: pearl.location.z
  };
  const targetDimension = pearl.dimension || null;

  teleportPlayer(owner, {
    dimensionId: targetDimension?.id || null,
    location: targetLocation
  });

  maybeSpawnEndermite(targetDimension, targetLocation);

  portalCooldowns.set(pearl.id, tickCount + 6);
  pearlStateById.delete(pearl.id);

  try {
    pearl.kill();
  } catch (e) {
    // ignore
  }
}

function checkPearlImpactState() {
  for (const dimension of getAllDimensions()) {
    const pearls = getEntitiesByType(dimension, "minecraft:ender_pearl");
    for (const pearl of pearls) {
      if (!pearl || !pearl.isValid) continue;
      if (portalCooldowns.has(pearl.id)) continue;

      const owner = getPearlOwner(pearl);
      if (owner && owner.isValid && isPearlImpactCandidate(pearl)) {
        handlePearlImpact(pearl);
        continue;
      }

      if (owner && owner.isValid) {
        pearlStateById.set(pearl.id, {
          ownerId: owner.id,
          dimensionId: pearl.dimension?.id || owner.dimension?.id || null
        });
      }
    }
  }
}

function getEntitiesByType(dimension, typeId) {
  try {
    const all = typeof dimension.getEntities === "function" ? dimension.getEntities() : [];
    if (!all || typeof all[Symbol.iterator] !== "function") return [];
    const result = [];
    for (const entity of all) {
      if (!entity) continue;
      if (entity.typeId === typeId) result.push(entity);
    }
    return result;
  } catch (e) {
    return [];
  }
}

function getPlayerById(playerId) {
  if (!playerId) return null;
  return world.getPlayers().find((player) => player && player.isValid && player.id === playerId) || null;
}

function getPearlOwner(pearl) {
  if (!pearl) return null;

  if (pearl.owner && pearl.owner.id) return pearl.owner;

  const projectileComp = pearl.getComponent("minecraft:projectile");
  if (projectileComp && projectileComp.owner) {
    return projectileComp.owner;
  }

  const entry = pearlStateById.get(pearl.id);
  if (entry && entry.ownerId) {
    const player = getPlayerById(entry.ownerId);
    if (player && player.isValid) return player;
  }

  return null;
}

function savePearlState(pearl, ownerName) {
  if (!pearl || !pearl.isValid || !ownerName) return;

  const state = {
    ownerName,
    dimensionId: pearl.dimension?.id || null,
    location: vectorToObject(pearl.location),
    velocity: pearl.getVelocity ? vectorToObject(pearl.getVelocity()) : { x: 0, y: 0, z: 0 }
  };

  const placeholder = pearl.dimension?.spawnEntity("sisso:ender_pearl_placeholder", pearl.location);

  if (!placeholder || !placeholder.isValid) {
    log(`Failed to spawn placeholder for ${ownerName}'s pearl; keeping pearl alive instead of killing it.`);
    return;
  }

  let list = ownerOrphanedPearls.get(ownerName);
  if (!list) {
    list = [];
    ownerOrphanedPearls.set(ownerName, list);
  }
  list.push({ placeholderId: placeholder.id, state });

  try {
    pearl.kill();
  } catch (e) {
    // ignore
  }
}

function restorePearlState(player) {
  if (!player || !player.isValid) return;

  const list = ownerOrphanedPearls.get(player.name);
  if (!list || list.length === 0) return;

  for (const entry of list) {
    const state = entry.state;
    const placeholderDimension = getDimensionById(state.dimensionId);
    const placeholder = placeholderDimension?.getEntities?.({ type: "sisso:ender_pearl_placeholder" })
      ?.find((entity) => entity.id === entry.placeholderId);

    if (placeholder && placeholder.isValid) {
      try {
        placeholder.kill();
      } catch (e) {
        // ignore
      }
    }

    const targetDimension = getDimensionById(state.dimensionId);
    if (!targetDimension) continue;

    const pearl = targetDimension.spawnEntity("minecraft:ender_pearl", state.location);
    if (pearl && pearl.isValid && pearl.setVelocity) {
      pearl.setVelocity(objectToVector(state.velocity));
      pearlStateById.set(pearl.id, {
        ownerId: player.id,
        dimensionId: targetDimension.id
      });
    }
  }

  ownerOrphanedPearls.delete(player.name);
  log(`Restored ${list.length} pearl(s) for ${player.name}`);
}

function handlePlayerLeave(playerId, playerName) {
  for (const [pearlId, state] of pearlStateById) {
    const dimension = getDimensionById(state.dimensionId);
    if (!dimension) continue;

    const pearl = getEntitiesByType(dimension, "minecraft:ender_pearl")
      .find((entity) => entity.id === pearlId);
    if (!pearl || !pearl.isValid) continue;

    const owner = getPearlOwner(pearl);
    const ownerId = owner && owner.isValid ? owner.id : state.ownerId;
    if (ownerId === playerId) {
      savePearlState(pearl, playerName);
      pearlStateById.delete(pearlId);
    }
  }
}

// FIX: was previously defined as `updatePlayerPreAsence` (typo) while
// tickHandler called `updatePlayerPresence` — a name that didn't exist.
// That threw a ReferenceError every single tick, before
// trackActivePearls()/checkPearlImpactState() ever ran, so none of the
// impact-detection logic below was actually executing.
function updatePlayerPresence() {
  const players = world.getPlayers();
  const currentPlayers = new Map(players.map((player) => [player.id, player.name]));

  for (const [previousId, previousName] of activePlayers) {
    if (!currentPlayers.has(previousId)) {
      handlePlayerLeave(previousId, previousName);
    }
  }

  for (const player of players) {
    if (!activePlayers.has(player.id)) {
      restorePearlState(player);
    }
  }

  activePlayers.clear();
  for (const [id, name] of currentPlayers) {
    activePlayers.set(id, name);
  }
}

function trackActivePearls() {
  for (const dimension of getAllDimensions()) {
    const pearls = getEntitiesByType(dimension, "minecraft:ender_pearl");
    for (const pearl of pearls) {
      if (!pearl || !pearl.isValid) continue;

      const owner = getPearlOwner(pearl);
      if (owner && owner.isValid) {
        pearlStateById.set(pearl.id, {
          ownerId: owner.id,
          dimensionId: pearl.dimension?.id || owner.dimension?.id || null
        });
      }
    }
  }
}

function tickHandler() {
  tickCount += 1;

  for (const [pearlId, expiry] of portalCooldowns) {
    if (expiry <= tickCount) portalCooldowns.delete(pearlId);
  }

  updatePlayerPresence();
  trackActivePearls();
  checkPearlImpactState();
}

if (world.events && world.events.tick && typeof world.events.tick.subscribe === "function") {
  world.events.tick.subscribe(tickHandler);
} else if (system && typeof system.runInterval === "function") {
  system.runInterval(tickHandler, 1);
} else {
  console.warn("Persist-only ender pearl script: no tick event API available");
}