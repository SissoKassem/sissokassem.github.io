import { world, system } from "@minecraft/server";

const trackedPearls = new Set();

system.runInterval(() => {
  const dimension = world.getDimension("minecraft:overworld");
  if (!dimension) return;

  const pearls = dimension.getEntities({ type: "minecraft:ender_pearl" });
  for (const pearl of pearls) {
    if (!pearl.isValid) continue;

    if (!trackedPearls.has(pearl.id)) {
      trackedPearls.add(pearl.id);

      const projectileComp = pearl.getComponent("minecraft:projectile");
      if (projectileComp) {
        projectileComp.airInertia = 0.99;
        projectileComp.liquidInertia = 0.83;

      }
    }
  }

  // Optional: clean up trackedPearls for pearls no longer valid
  for (const id of trackedPearls) {
    // Implement logic to remove invalid pearl IDs if needed
  }
}, 1); // run every tick
