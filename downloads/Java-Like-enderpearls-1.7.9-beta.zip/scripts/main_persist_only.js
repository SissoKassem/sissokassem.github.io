import { world, system } from "@minecraft/server";

const DEBUG = false;
const pearlStateById = new Map();
const ownerOrphanedPearls = new Map();
const activePlayerIds = new Set();
let tickCount = 0;

function getAllDimensions() {
  try {
    if (typeof world.getDimensions === "function") return world.getDimensions();
    const ids = ["minecraft:overworld", "minecraft:the_nether", "minecraft:the_end", "minecraft:nether", "minecraft:end"];
    const dims = [];
    for (const id of ids) {
      try {
        const d = world.getDimension(id);
        if (d) dims.push(d);
      } catch (e) {
        // ignore
      }
    }
    return dims;
  } catch (e) {
    return [];
  }
}

function normalizeDimensionId(dimensionId) {
  if (!dimensionId) return "";
  return dimensionId.toString().replace(/^minecraft:/, "").toLowerCase();
}

function getDimensionById(dimensionId) {
  if (!dimensionId) return null;
  try {
    if (typeof world.getDimension === "function") {
      try {
        const direct = world.getDimension(dimensionId);
        if (direct) return direct;
      } catch (e) {
        // ignore
      }
    }
  } catch (e) {
    // ignore
  }

  const normalized = normalizeDimensionId(dimensionId);
  for (const dimension of getAllDimensions()) {
    if (!dimension || !dimension.id) continue;
    const id = dimension.id.toString().toLowerCase();
    const simple = id.replace(/^minecraft:/, "");
    if (id === normalized || simple === normalized || id.endsWith(`:${normalized}`) || simple === normalized) {
      return dimension;
    }
    if (id.includes(normalized) || simple.includes(normalized)) {
      return dimension;
    }
  }

  return null;
}

function vectorToObject(vector) {
  return { x: vector.x, y: vector.y, z: vector.z };
}

function objectToVector(obj) {
  return { x: obj.x, y: obj.y, z: obj.z };
}

function getEntitiesByType(dimension, typeId) {
  try {
    const all = typeof dimension.getEntities === "function" ? dimension.getEntities() : [];
    if (!all || typeof all[Symbol.iterator] !== "function") return [];
    const result = [];
    for (const entity of all) {
      if (!entity) continue;
      if (entity.typeId === typeId) result.push(entity);
    }
    return result;
  } catch (e) {
    return [];
  }
}

function getPlayerById(playerId) {
  if (!playerId) return null;
  return world.getPlayers().find((player) => player && player.isValid && player.id === playerId) || null;
}

function getPearlOwner(pearl) {
  if (!pearl) return null;

  if (pearl.owner && pearl.owner.id) return pearl.owner;

  const projectileComp = pearl.getComponent("minecraft:projectile");
  if (projectileComp && projectileComp.owner) {
    return projectileComp.owner;
  }

  const entry = pearlStateById.get(pearl.id);
  if (entry && entry.ownerId) {
    const player = getPlayerById(entry.ownerId);
    if (player && player.isValid) return player;
  }

  return null;
}

function savePearlState(pearl, ownerId) {
  if (!pearl || !pearl.isValid || !ownerId) return;

  const state = {
    ownerId,
    dimensionId: pearl.dimension?.id || null,
    location: vectorToObject(pearl.location),
    velocity: pearl.getVelocity ? vectorToObject(pearl.getVelocity()) : { x: 0, y: 0, z: 0 }
  };

  const placeholder = pearl.dimension?.spawnEntity("sisso:ender_pearl_placeholder", pearl.location);
  if (placeholder && placeholder.isValid) {
    let list = ownerOrphanedPearls.get(ownerId);
    if (!list) {
      list = [];
      ownerOrphanedPearls.set(ownerId, list);
    }
    list.push({ placeholderId: placeholder.id, state });
  }

  try {
    pearl.kill();
  } catch (e) {
    // ignore
  }
}

function restorePearlState(player) {
  if (!player || !player.isValid) return;

  const list = ownerOrphanedPearls.get(player.id);
  if (!list || list.length === 0) return;

  for (const entry of list) {
    const state = entry.state;
    const placeholderDimension = getDimensionById(state.dimensionId);
    const placeholder = placeholderDimension?.getEntities?.({ type: "sisso:ender_pearl_placeholder" })
      ?.find((entity) => entity.id === entry.placeholderId);

    if (placeholder && placeholder.isValid) {
      try {
        placeholder.kill();
      } catch (e) {
        // ignore
      }
    }

    const targetDimension = getDimensionById(state.dimensionId);
    if (!targetDimension) continue;

    const pearl = targetDimension.spawnEntity("minecraft:ender_pearl", state.location);
    if (pearl && pearl.isValid && pearl.setVelocity) {
      pearl.setVelocity(objectToVector(state.velocity));
      pearlStateById.set(pearl.id, {
        ownerId: player.id,
        dimensionId: targetDimension.id
      });
    }
  }

  ownerOrphanedPearls.delete(player.id);
}

function handlePlayerLeave(playerId) {
  for (const [pearlId, state] of pearlStateById) {
    const dimension = getDimensionById(state.dimensionId);
    if (!dimension) continue;

    const pearl = getEntitiesByType(dimension, "minecraft:ender_pearl")
      .find((entity) => entity.id === pearlId);
    if (!pearl || !pearl.isValid) continue;

    const owner = getPearlOwner(pearl);
    const ownerId = owner && owner.isValid ? owner.id : state.ownerId;
    if (ownerId === playerId) {
      savePearlState(pearl, playerId);
      pearlStateById.delete(pearlId);
    }
  }
}

function updatePlayerPresence() {
  const players = world.getPlayers();
  const currentPlayerIds = new Set(players.map((player) => player.id));

  for (const previousId of activePlayerIds) {
    if (!currentPlayerIds.has(previousId)) {
      handlePlayerLeave(previousId);
    }
  }

  for (const player of players) {
    if (!activePlayerIds.has(player.id)) {
      restorePearlState(player);
    }
  }

  activePlayerIds.clear();
  for (const playerId of currentPlayerIds) {
    activePlayerIds.add(playerId);
  }
}

function trackActivePearls() {
  for (const dimension of getAllDimensions()) {
    const pearls = getEntitiesByType(dimension, "minecraft:ender_pearl");
    for (const pearl of pearls) {
      if (!pearl || !pearl.isValid) continue;

      const owner = getPearlOwner(pearl);
      if (owner && owner.isValid) {
        pearlStateById.set(pearl.id, {
          ownerId: owner.id,
          dimensionId: pearl.dimension?.id || owner.dimension?.id || null
        });
      }
    }
  }
}

function tickHandler() {
  tickCount += 1;
  updatePlayerPresence();
  trackActivePearls();
}

if (world.events && world.events.tick && typeof world.events.tick.subscribe === "function") {
  world.events.tick.subscribe(tickHandler);
} else if (system && typeof system.runInterval === "function") {
  system.runInterval(tickHandler, 1);
} else {
  console.warn("Persist-only ender pearl script: no tick event API available");
}
