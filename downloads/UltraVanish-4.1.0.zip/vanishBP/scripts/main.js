import {
    world,
    system,
    CommandPermissionLevel,
    CustomCommandStatus
} from "@minecraft/server";

const vanishedPlayers = new Set();
const playerNames = new Map();

function sendMessage(player, message) {
    player.sendMessage(message)
}

// Return players without "vanished" tag
function getVisiblePlayers() {
    return world.getPlayers().filter(p => !p.hasTag("vanished"));
}

// Toggle vanish for a player using addEffect and removeEffect API
function toggleVanish(player) {
    if (player.hasTag("vanished")) {
	system.run(() => {
      	    player.runCommand(`tag ${player.name} remove vanished`);
	    player.runCommand(`effect ${player.name} clear invisibility`);
            player.runCommand(`title ${player.name} actionbar §aYou are now visible`)
	});
	    world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} joined the game.`));
        return false; // vanished off
    } else {
	system.run(() => {
      	    player.runCommand(`tag ${player.name} add vanished`);
	    player.runCommand(`effect ${player.name} invisibility infinite 1 true`);
	});
	    world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} left the game.`));
        return true; // vanished on
    }
}

// Register commands on startup using customCommandRegistry
system.beforeEvents.startup.subscribe(({
    customCommandRegistry
}) => {
    // vanish toggle command (admin only)
    customCommandRegistry.registerCommand({
            name: "vanish:vanish",
            description: "Toggle vanish mode",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        origin => {
            if (!origin.sourceEntity) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Command must be run by a player."
                };
            }
            const player = origin.sourceEntity;
            const vanished = toggleVanish(player);
            if (vanished) vanishedPlayers.add(player.id);
            else vanishedPlayers.delete(player.id);
            return {
                status: CustomCommandStatus.Success
            };
        }
    );

    // online player list command (anyone)
    customCommandRegistry.registerCommand({
            name: "vanish:online",
            description: "List online players",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        origin => {
            if (!origin.sourceEntity) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Command must be run by a player."
                };
            }
            const player = origin.sourceEntity;
            const visiblePlayers = getVisiblePlayers();

            if (visiblePlayers.length === 0) {
                sendMessage(player, "No players online.");
                return {
                    status: CustomCommandStatus.Success
                };
            }

            sendMessage(player, `Players online: ${visiblePlayers.map(p => p.name).join(", ")}`);
            return {
                status: CustomCommandStatus.Success
            };
        }
    );
});

// Suppress join message for vanished players and welcome others
world.afterEvents.playerJoin.subscribe(ev => {
    const player = world.getPlayers().find(p => p.id === ev.playerId);
    if (!player) return;

    playerNames.set(player.id, player.name);

    if (player.hasTag("vanished")) {
        vanishedPlayers.add(player.id);
        return; // suppress join message
    }
    vanishedPlayers.delete(player.id);
    world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} joined the game`));
});

// Suppress leave message for vanished players and announce others
world.afterEvents.playerLeave.subscribe(ev => {
    const playerName = playerNames.get(ev.playerId) || ev.playerName || "A player";

    if (vanishedPlayers.has(ev.playerId)) {
        vanishedPlayers.delete(ev.playerId);
        playerNames.delete(ev.playerId);
        return;
    }
    playerNames.delete(ev.playerId);
    world.getPlayers().forEach(p => sendMessage(p, `§e${playerName} left the game.`));
});


const intervalId = system.runInterval(() => {
    // Your repeated code here
    system.run(() => {
	const dimension = world.getDimension("overworld");
        dimension.runCommand(`title @a[tag=vanished] actionbar §4You are now vanished`)
	dimension.runCommand(`playanimation @a[tag=vanished] animation.player.vanish none 0.5 "true"`)
    });
}, 1);