import {
    world,
    system,
    CommandPermissionLevel,
    CustomCommandStatus
} from "@minecraft/server";

const vanishedPlayers = new Set();
const playerNames = new Map();

function sendMessage(player, message) {
    player.sendMessage(message);
}

// Return players without "vanished" tag
function getVisiblePlayers() {
    return world.getPlayers().filter(p => !p.hasTag("vanished"));
}

// Toggle vanish for a player using addEffect and removeEffect API
function toggleVanish(player) {
    if (player.hasTag("vanished")) {
        system.run(() => {
            player.runCommand(`tag ${player.name} remove vanished`);
            player.runCommand(`effect ${player.name} clear invisibility`);
            player.runCommand(`title ${player.name} actionbar §aYou are now visible`);
        });
        world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} joined the game`));
        return false; // vanish off
    } else {
        system.run(() => {
            player.runCommand(`tag ${player.name} add vanished`);
            player.runCommand(`effect ${player.name} invisibility infinite 1 true`);
        });
        world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} left the game`));
        return true; // vanish on
    }
}

// Register commands on startup using customCommandRegistry
system.beforeEvents.startup.subscribe(({ customCommandRegistry }) => {
    // vanish toggle command (admin only)
    customCommandRegistry.registerCommand(
        {
            name: "vanish:vanish",
            description: "Toggle vanish mode",
            permissionLevel: CommandPermissionLevel.GameDirectors,
            cheatsRequired: false,
        },
        origin => {
            if (!origin.sourceEntity) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Command must be run by a player."
                };
            }
            const player = origin.sourceEntity;
            const vanished = toggleVanish(player);
            if (vanished) vanishedPlayers.add(player.id);
            else vanishedPlayers.delete(player.id);
            return { status: CustomCommandStatus.Success };
        }
    );

    // online player list command (anyone)
    customCommandRegistry.registerCommand(
        {
            name: "vanish:online",
            description: "List online players",
            permissionLevel: CommandPermissionLevel.Any,
            cheatsRequired: false,
        },
        origin => {
            if (!origin.sourceEntity) {
                return {
                    status: CustomCommandStatus.Failure,
                    message: "Command must be run by a player."
                };
            }
            const player = origin.sourceEntity;
            const visiblePlayers = getVisiblePlayers();

            if (visiblePlayers.length === 0) {
                sendMessage(player, "No players online.");
                return { status: CustomCommandStatus.Success };
            }

            sendMessage(player, `Players online: ${visiblePlayers.map(p => p.name).join(", ")}`);
            return { status: CustomCommandStatus.Success };
        }
    );
});

// playerJoin only provides an id/name and fires before the entity is guaranteed to be
// spawned in, so world.getPlayers().find(...) can miss it and silently skip the message.
// playerSpawn (with initialSpawn === true) gives you the real player entity and only
// fires once they're actually in the world, so it's the reliable event to use here.
world.afterEvents.playerSpawn.subscribe(ev => {
    if (!ev.initialSpawn) return; // skip respawns after death, only handle real joins

    const player = ev.player;
    playerNames.set(player.id, player.name);

    if (player.hasTag("vanished")) {
        vanishedPlayers.add(player.id);
        return; // suppress join message while vanished
    }

    vanishedPlayers.delete(player.id);
    world.getPlayers().forEach(p => sendMessage(p, `§e${player.name} joined the game`));
});

// Suppress leave message for vanished players and announce others
world.afterEvents.playerLeave.subscribe(ev => {
    const playerName = playerNames.get(ev.playerId) ?? ev.playerName ?? "A player";
    playerNames.delete(ev.playerId);

    if (vanishedPlayers.has(ev.playerId)) {
        vanishedPlayers.delete(ev.playerId);
        return; // suppress leave message for vanished players
    }

    world.getPlayers().forEach(p => sendMessage(p, `§e${playerName} left the game`));
});

system.runInterval(() => {
    system.run(() => {
        const dimension = world.getDimension("overworld");
        dimension.runCommand(`title @a[tag=vanished] actionbar §4You are now vanished`);
        dimension.runCommand(`playanimation @a[tag=vanished] animation.player.vanish none 0.5 "true"`);

        // Keep vanishedPlayers authoritative on the actual "vanished" tag rather than
        // trusting only the join/leave/command events. If the script ever reloads
        // mid-session (world reload, pack update) while someone is vanished, the
        // in-memory Set would otherwise forget them and their next leave message
        // would slip through even though the tag is still on them.
        for (const p of world.getPlayers()) {
            if (p.hasTag("vanished")) vanishedPlayers.add(p.id);
            else vanishedPlayers.delete(p.id);
        }
    });
}, 1);