# Add the vanished tag
tag @s add vanished

# Give invisibility effect infinitely with no particles
effect @s invisibility infinite 1 true

# Send a message to all players that the player has left (simulate leaving)
tellraw @a {"rawtext":[{"text":"§e"},{ "selector":"@s" },{"text":" has left the game"}]}

# Show the player an action bar message that they are vanished
title @s actionbar §6You are now vanished