# Remove the vanished tag
tag @s remove vanished

# Clear invisibility effect
effect @s clear invisibility

# Send a message to all players that the player has joined (simulate joining)
tellraw @a {"rawtext":[{"text":"§e"},{ "selector":"@s" },{"text":" has joined the game"}]}

# Show the player an action bar message that they are no longer vanished
title @s actionbar §aYou are no longer vanished