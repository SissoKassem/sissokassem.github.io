import { world, system } from "@minecraft/server";

// Utility function to get player by ID
function getPlayerById(playerId) {
  return world.getPlayers().find(player => player.id === playerId);
}

// Utility function to get all non-vanished players
function getVisiblePlayers() {
  return world.getPlayers().filter(player => !player.hasTag("vanished"));
}

const vanishedPlayers = new Set();
const playerNames = new Map();

world.afterEvents.playerJoin.subscribe(event => {
  const player = getPlayerById(event.playerId);
  if (!player) return;

  playerNames.set(player.id, player.name);

  if (player.hasTag("vanished")) {
    vanishedPlayers.add(player.id);
    return; // suppress join message
  } else {
    vanishedPlayers.delete(player.id);
    world.getPlayers().forEach(p => {
      p.sendMessage(`§e ${player.name} has joined the game!`);
    });
  }

  system.run(() => updatePlayerListData());
});

world.afterEvents.playerLeave.subscribe(event => {
  const playerId = event.playerId;
  const playerName = playerNames.get(playerId) || event.playerName || "A player";

  if (vanishedPlayers.has(playerId)) {
    vanishedPlayers.delete(playerId);
    playerNames.delete(playerId);
    return; // suppress leave message
  }

  playerNames.delete(playerId);
  world.getPlayers().forEach(p => {
    p.sendMessage(`§e ${playerName} has left the game`);
  });

  system.run(() => updatePlayerListData());
});

let currentPlayerList = [];

function updatePlayerListData() {
  currentPlayerList = getVisiblePlayers().map(p => p.name);
}

world.beforeEvents.chatSend.subscribe(event => {
  const message = event.message.trim().toLowerCase();
  const player = event.sender;

  if (message === ";online") {
    event.cancel = true; // Prevent the message from showing in chat
    const visiblePlayers = getVisiblePlayers();
    if (visiblePlayers.length === 0) {
      player.sendMessage("No visible players online.");
      return;
    }
    const playerNamesList = visiblePlayers.map(p => p.name).join(", ");
    player.sendMessage(`Visible players online: ${playerNamesList}`);
    return;
  }

  if (message === ";vanish") {
    event.cancel = true;
    if (!player.hasTag("staff")) {
      player.sendMessage("§cYou do not have permission to use this command.");
      return;
    }
    system.run(() => {
      player.runCommand("function vanish");
    });
    return;
  }

  if (message === ";unvanish") {
    event.cancel = true;
    if (!player.hasTag("staff")) {
      player.sendMessage("§cYou do not have permission to use this command.");
      return;
    }
    system.run(() => {
      player.runCommand("function unvanish");
    });
    return;
  }
});
